# APComputerScienceP_ImageFilter
A library may need to be installed with the following command:
pip install pillow
